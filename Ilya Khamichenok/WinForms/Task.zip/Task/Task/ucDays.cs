﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task
{    
    public partial class ucDays : UserControl
    {
        private string day, date, weekday;
        public ucDays(string day)
        {
            InitializeComponent();
            this.day = day;
            label1.Text = day;
            checkBox1.Hide();
        }

        private void ucDays_Load(object sender, EventArgs e)
        {

        }
    }
}
