using System.Globalization;

namespace Task
{
    public partial class Form1 : Form
    {
        private int year, month;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ShowDays(DateTime.Now.Month, DateTime.Now.Year);
        }

        private void ShowDays(int month, int year)
        {
            flowLayoutPanel1.Controls.Clear();
            this.month = month;
            this.year = year;

            var monthName = new DateTimeFormatInfo().GetMonthName(month);
            lbMonth.Text = monthName.ToString().ToUpper() + " " + year;
            var startedTheMonth = new DateTime(year, month, 1);
            var day = DateTime.DaysInMonth(year, month);
            var week = Convert.ToInt32(startedTheMonth.DayOfWeek.ToString("d")) + 6;

            for (int i = 1; i <= week; i++)
            {
                var uc = new ucDays("");
                flowLayoutPanel1.Controls.Add(uc);
            }

            for (int i = 1; i <= day; i++)
            {
                var uc = new ucDays(i + "");
                flowLayoutPanel1.Controls.Add(uc);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
