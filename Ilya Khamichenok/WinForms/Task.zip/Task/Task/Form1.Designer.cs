﻿namespace Task
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            flowLayoutPanel1 = new FlowLayoutPanel();
            panel2 = new Panel();
            panel1 = new Panel();
            panel4 = new Panel();
            panel3 = new Panel();
            panel6 = new Panel();
            panel5 = new Panel();
            panel14 = new Panel();
            panel7 = new Panel();
            panel13 = new Panel();
            panel12 = new Panel();
            panel11 = new Panel();
            panel10 = new Panel();
            panel9 = new Panel();
            panel8 = new Panel();
            panel22 = new Panel();
            panel20 = new Panel();
            panel19 = new Panel();
            panel18 = new Panel();
            panel17 = new Panel();
            panel16 = new Panel();
            panel35 = new Panel();
            panel15 = new Panel();
            panel34 = new Panel();
            panel33 = new Panel();
            panel32 = new Panel();
            panel31 = new Panel();
            panel30 = new Panel();
            panel29 = new Panel();
            panel21 = new Panel();
            panel23 = new Panel();
            panel25 = new Panel();
            panel24 = new Panel();
            panel26 = new Panel();
            panel27 = new Panel();
            panel28 = new Panel();
            panel36 = new Panel();
            panel37 = new Panel();
            panel38 = new Panel();
            panel39 = new Panel();
            panel40 = new Panel();
            panel41 = new Panel();
            panel42 = new Panel();
            panel43 = new Panel();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            lbMonth = new Label();
            flowLayoutPanel1.SuspendLayout();
            panel9.SuspendLayout();
            SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Controls.Add(panel2);
            flowLayoutPanel1.Controls.Add(panel1);
            flowLayoutPanel1.Controls.Add(panel4);
            flowLayoutPanel1.Controls.Add(panel3);
            flowLayoutPanel1.Controls.Add(panel6);
            flowLayoutPanel1.Controls.Add(panel5);
            flowLayoutPanel1.Controls.Add(panel14);
            flowLayoutPanel1.Controls.Add(panel7);
            flowLayoutPanel1.Controls.Add(panel13);
            flowLayoutPanel1.Controls.Add(panel12);
            flowLayoutPanel1.Controls.Add(panel11);
            flowLayoutPanel1.Controls.Add(panel10);
            flowLayoutPanel1.Controls.Add(panel9);
            flowLayoutPanel1.Controls.Add(panel22);
            flowLayoutPanel1.Controls.Add(panel20);
            flowLayoutPanel1.Controls.Add(panel19);
            flowLayoutPanel1.Controls.Add(panel18);
            flowLayoutPanel1.Controls.Add(panel17);
            flowLayoutPanel1.Controls.Add(panel16);
            flowLayoutPanel1.Controls.Add(panel35);
            flowLayoutPanel1.Controls.Add(panel15);
            flowLayoutPanel1.Controls.Add(panel34);
            flowLayoutPanel1.Controls.Add(panel33);
            flowLayoutPanel1.Controls.Add(panel32);
            flowLayoutPanel1.Controls.Add(panel31);
            flowLayoutPanel1.Controls.Add(panel30);
            flowLayoutPanel1.Controls.Add(panel29);
            flowLayoutPanel1.Controls.Add(panel21);
            flowLayoutPanel1.Controls.Add(panel23);
            flowLayoutPanel1.Controls.Add(panel25);
            flowLayoutPanel1.Controls.Add(panel24);
            flowLayoutPanel1.Controls.Add(panel26);
            flowLayoutPanel1.Controls.Add(panel27);
            flowLayoutPanel1.Controls.Add(panel28);
            flowLayoutPanel1.Controls.Add(panel36);
            flowLayoutPanel1.Controls.Add(panel37);
            flowLayoutPanel1.Controls.Add(panel38);
            flowLayoutPanel1.Controls.Add(panel39);
            flowLayoutPanel1.Controls.Add(panel40);
            flowLayoutPanel1.Controls.Add(panel41);
            flowLayoutPanel1.Controls.Add(panel42);
            flowLayoutPanel1.Controls.Add(panel43);
            flowLayoutPanel1.Location = new Point(11, 139);
            flowLayoutPanel1.Margin = new Padding(0);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(1259, 913);
            flowLayoutPanel1.TabIndex = 2;
            // 
            // panel2
            // 
            panel2.Location = new Point(1, 1);
            panel2.Margin = new Padding(1);
            panel2.Name = "panel2";
            panel2.Size = new Size(173, 142);
            panel2.TabIndex = 1;
            // 
            // panel1
            // 
            panel1.Location = new Point(176, 1);
            panel1.Margin = new Padding(1);
            panel1.Name = "panel1";
            panel1.Size = new Size(173, 142);
            panel1.TabIndex = 2;
            // 
            // panel4
            // 
            panel4.Location = new Point(351, 1);
            panel4.Margin = new Padding(1);
            panel4.Name = "panel4";
            panel4.Size = new Size(173, 142);
            panel4.TabIndex = 4;
            // 
            // panel3
            // 
            panel3.Location = new Point(526, 1);
            panel3.Margin = new Padding(1);
            panel3.Name = "panel3";
            panel3.Size = new Size(173, 142);
            panel3.TabIndex = 3;
            // 
            // panel6
            // 
            panel6.Location = new Point(701, 1);
            panel6.Margin = new Padding(1);
            panel6.Name = "panel6";
            panel6.Size = new Size(173, 142);
            panel6.TabIndex = 4;
            // 
            // panel5
            // 
            panel5.Location = new Point(876, 1);
            panel5.Margin = new Padding(1);
            panel5.Name = "panel5";
            panel5.Size = new Size(173, 142);
            panel5.TabIndex = 3;
            // 
            // panel14
            // 
            panel14.Location = new Point(1051, 1);
            panel14.Margin = new Padding(1);
            panel14.Name = "panel14";
            panel14.Size = new Size(173, 142);
            panel14.TabIndex = 11;
            // 
            // panel7
            // 
            panel7.Location = new Point(1, 145);
            panel7.Margin = new Padding(1);
            panel7.Name = "panel7";
            panel7.Size = new Size(173, 142);
            panel7.TabIndex = 4;
            // 
            // panel13
            // 
            panel13.Location = new Point(176, 145);
            panel13.Margin = new Padding(1);
            panel13.Name = "panel13";
            panel13.Size = new Size(173, 142);
            panel13.TabIndex = 8;
            // 
            // panel12
            // 
            panel12.Location = new Point(351, 145);
            panel12.Margin = new Padding(1);
            panel12.Name = "panel12";
            panel12.Size = new Size(173, 142);
            panel12.TabIndex = 10;
            // 
            // panel11
            // 
            panel11.Location = new Point(526, 145);
            panel11.Margin = new Padding(1);
            panel11.Name = "panel11";
            panel11.Size = new Size(173, 142);
            panel11.TabIndex = 7;
            // 
            // panel10
            // 
            panel10.Location = new Point(701, 145);
            panel10.Margin = new Padding(1);
            panel10.Name = "panel10";
            panel10.Size = new Size(173, 142);
            panel10.TabIndex = 9;
            // 
            // panel9
            // 
            panel9.Controls.Add(panel8);
            panel9.Location = new Point(876, 145);
            panel9.Margin = new Padding(1);
            panel9.Name = "panel9";
            panel9.Size = new Size(173, 142);
            panel9.TabIndex = 6;
            // 
            // panel8
            // 
            panel8.Location = new Point(174, 112);
            panel8.Margin = new Padding(1);
            panel8.Name = "panel8";
            panel8.Size = new Size(173, 142);
            panel8.TabIndex = 5;
            // 
            // panel22
            // 
            panel22.Location = new Point(1051, 145);
            panel22.Margin = new Padding(1);
            panel22.Name = "panel22";
            panel22.Size = new Size(173, 142);
            panel22.TabIndex = 18;
            // 
            // panel20
            // 
            panel20.Location = new Point(1, 289);
            panel20.Margin = new Padding(1);
            panel20.Name = "panel20";
            panel20.Size = new Size(173, 142);
            panel20.TabIndex = 15;
            // 
            // panel19
            // 
            panel19.Location = new Point(176, 289);
            panel19.Margin = new Padding(1);
            panel19.Name = "panel19";
            panel19.Size = new Size(173, 142);
            panel19.TabIndex = 17;
            // 
            // panel18
            // 
            panel18.Location = new Point(351, 289);
            panel18.Margin = new Padding(1);
            panel18.Name = "panel18";
            panel18.Size = new Size(173, 142);
            panel18.TabIndex = 14;
            // 
            // panel17
            // 
            panel17.Location = new Point(526, 289);
            panel17.Margin = new Padding(1);
            panel17.Name = "panel17";
            panel17.Size = new Size(173, 142);
            panel17.TabIndex = 16;
            // 
            // panel16
            // 
            panel16.Location = new Point(701, 289);
            panel16.Margin = new Padding(1);
            panel16.Name = "panel16";
            panel16.Size = new Size(173, 142);
            panel16.TabIndex = 13;
            // 
            // panel35
            // 
            panel35.Location = new Point(876, 289);
            panel35.Margin = new Padding(1);
            panel35.Name = "panel35";
            panel35.Size = new Size(173, 142);
            panel35.TabIndex = 19;
            // 
            // panel15
            // 
            panel15.Location = new Point(1051, 289);
            panel15.Margin = new Padding(1);
            panel15.Name = "panel15";
            panel15.Size = new Size(173, 142);
            panel15.TabIndex = 12;
            // 
            // panel34
            // 
            panel34.Location = new Point(1, 433);
            panel34.Margin = new Padding(1);
            panel34.Name = "panel34";
            panel34.Size = new Size(173, 142);
            panel34.TabIndex = 20;
            // 
            // panel33
            // 
            panel33.Location = new Point(176, 433);
            panel33.Margin = new Padding(1);
            panel33.Name = "panel33";
            panel33.Size = new Size(173, 142);
            panel33.TabIndex = 23;
            // 
            // panel32
            // 
            panel32.Location = new Point(351, 433);
            panel32.Margin = new Padding(1);
            panel32.Name = "panel32";
            panel32.Size = new Size(173, 142);
            panel32.TabIndex = 21;
            // 
            // panel31
            // 
            panel31.Location = new Point(526, 433);
            panel31.Margin = new Padding(1);
            panel31.Name = "panel31";
            panel31.Size = new Size(173, 142);
            panel31.TabIndex = 24;
            // 
            // panel30
            // 
            panel30.Location = new Point(701, 433);
            panel30.Margin = new Padding(1);
            panel30.Name = "panel30";
            panel30.Size = new Size(173, 142);
            panel30.TabIndex = 22;
            // 
            // panel29
            // 
            panel29.Location = new Point(876, 433);
            panel29.Margin = new Padding(1);
            panel29.Name = "panel29";
            panel29.Size = new Size(173, 142);
            panel29.TabIndex = 25;
            // 
            // panel21
            // 
            panel21.Location = new Point(1051, 433);
            panel21.Margin = new Padding(1);
            panel21.Name = "panel21";
            panel21.Size = new Size(173, 142);
            panel21.TabIndex = 26;
            // 
            // panel23
            // 
            panel23.Location = new Point(1, 577);
            panel23.Margin = new Padding(1);
            panel23.Name = "panel23";
            panel23.Size = new Size(173, 142);
            panel23.TabIndex = 26;
            // 
            // panel25
            // 
            panel25.Location = new Point(176, 577);
            panel25.Margin = new Padding(1);
            panel25.Name = "panel25";
            panel25.Size = new Size(173, 142);
            panel25.TabIndex = 26;
            // 
            // panel24
            // 
            panel24.Location = new Point(351, 577);
            panel24.Margin = new Padding(1);
            panel24.Name = "panel24";
            panel24.Size = new Size(173, 142);
            panel24.TabIndex = 26;
            // 
            // panel26
            // 
            panel26.Location = new Point(526, 577);
            panel26.Margin = new Padding(1);
            panel26.Name = "panel26";
            panel26.Size = new Size(173, 142);
            panel26.TabIndex = 26;
            // 
            // panel27
            // 
            panel27.Location = new Point(701, 577);
            panel27.Margin = new Padding(1);
            panel27.Name = "panel27";
            panel27.Size = new Size(173, 142);
            panel27.TabIndex = 26;
            // 
            // panel28
            // 
            panel28.Location = new Point(876, 577);
            panel28.Margin = new Padding(1);
            panel28.Name = "panel28";
            panel28.Size = new Size(173, 142);
            panel28.TabIndex = 26;
            // 
            // panel36
            // 
            panel36.Location = new Point(1051, 577);
            panel36.Margin = new Padding(1);
            panel36.Name = "panel36";
            panel36.Size = new Size(173, 142);
            panel36.TabIndex = 26;
            // 
            // panel37
            // 
            panel37.Location = new Point(1, 721);
            panel37.Margin = new Padding(1);
            panel37.Name = "panel37";
            panel37.Size = new Size(173, 142);
            panel37.TabIndex = 27;
            // 
            // panel38
            // 
            panel38.Location = new Point(176, 721);
            panel38.Margin = new Padding(1);
            panel38.Name = "panel38";
            panel38.Size = new Size(173, 142);
            panel38.TabIndex = 27;
            // 
            // panel39
            // 
            panel39.Location = new Point(351, 721);
            panel39.Margin = new Padding(1);
            panel39.Name = "panel39";
            panel39.Size = new Size(173, 142);
            panel39.TabIndex = 27;
            // 
            // panel40
            // 
            panel40.Location = new Point(526, 721);
            panel40.Margin = new Padding(1);
            panel40.Name = "panel40";
            panel40.Size = new Size(173, 142);
            panel40.TabIndex = 27;
            // 
            // panel41
            // 
            panel41.Location = new Point(701, 721);
            panel41.Margin = new Padding(1);
            panel41.Name = "panel41";
            panel41.Size = new Size(173, 142);
            panel41.TabIndex = 27;
            // 
            // panel42
            // 
            panel42.Location = new Point(876, 721);
            panel42.Margin = new Padding(1);
            panel42.Name = "panel42";
            panel42.Size = new Size(173, 142);
            panel42.TabIndex = 27;
            // 
            // panel43
            // 
            panel43.Location = new Point(1051, 721);
            panel43.Margin = new Padding(1);
            panel43.Name = "panel43";
            panel43.Size = new Size(173, 142);
            panel43.TabIndex = 27;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(951, 103);
            label1.Name = "label1";
            label1.Size = new Size(67, 18);
            label1.TabIndex = 3;
            label1.Text = "Sunday";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(66, 103);
            label2.Name = "label2";
            label2.Size = new Size(70, 18);
            label2.TabIndex = 4;
            label2.Text = "Monday";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(244, 103);
            label3.Name = "label3";
            label3.Size = new Size(65, 18);
            label3.TabIndex = 5;
            label3.Text = "Tueday";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(402, 103);
            label4.Name = "label4";
            label4.Size = new Size(102, 18);
            label4.TabIndex = 6;
            label4.Text = "Wednesday";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(590, 103);
            label5.Name = "label5";
            label5.Size = new Size(82, 18);
            label5.TabIndex = 7;
            label5.Text = "Thursday";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(780, 103);
            label6.Name = "label6";
            label6.Size = new Size(57, 18);
            label6.TabIndex = 8;
            label6.Text = "Friday";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(1120, 103);
            label7.Name = "label7";
            label7.Size = new Size(80, 18);
            label7.TabIndex = 9;
            label7.Text = "Saturday";
            // 
            // lbMonth
            // 
            lbMonth.AutoSize = true;
            lbMonth.Font = new Font("Verdana", 14F);
            lbMonth.Location = new Point(25, 21);
            lbMonth.Name = "lbMonth";
            lbMonth.Size = new Size(81, 23);
            lbMonth.TabIndex = 10;
            lbMonth.Text = "MONTH";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1276, 1061);
            Controls.Add(lbMonth);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(flowLayoutPanel1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            flowLayoutPanel1.ResumeLayout(false);
            panel9.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private FlowLayoutPanel flowLayoutPanel1;
        private Label label1;
        private Panel panel2;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Panel panel1;
        private Panel panel4;
        private Panel panel3;
        private Panel panel6;
        private Panel panel5;
        private Panel panel14;
        private Panel panel7;
        private Panel panel13;
        private Panel panel12;
        private Panel panel11;
        private Panel panel10;
        private Panel panel9;
        private Panel panel8;
        private Panel panel22;
        private Panel panel20;
        private Panel panel19;
        private Panel panel18;
        private Panel panel17;
        private Panel panel16;
        private Panel panel35;
        private Panel panel15;
        private Panel panel34;
        private Panel panel33;
        private Panel panel32;
        private Panel panel31;
        private Panel panel30;
        private Panel panel29;
        private Label lbMonth;
        private Panel panel21;
        private Panel panel23;
        private Panel panel25;
        private Panel panel24;
        private Panel panel26;
        private Panel panel27;
        private Panel panel28;
        private Panel panel36;
        private Panel panel37;
        private Panel panel38;
        private Panel panel39;
        private Panel panel40;
        private Panel panel41;
        private Panel panel42;
        private Panel panel43;
    }
}
